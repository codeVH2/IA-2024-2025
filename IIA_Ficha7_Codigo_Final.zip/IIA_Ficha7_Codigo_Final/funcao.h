void evaluate(pchrom, struct info, int mat[][2]);

void trepa_colinas(pchrom, struct info, int mat[][2]);
